<?php
// پاک‌سازی تنظیمات هنگام حذف افزونه (متاهای تصاویر عمداً حفظ می‌شوند تا پردازش مجدد رخ ندهد)
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'osn_img_settings' );
delete_option( 'osn_img_version' );
delete_option( 'osn_img_scan_data' );
delete_option( 'osn_img_bulk_state' );
delete_option( 'osn_img_migrated_v39' );
// نام‌های قدیمی مبتنی بر jluxe (اگر مهاجرت به هر دلیلی اجرا نشده بود)
delete_option( 'jlx_img_settings' );
delete_option( 'jlx_img_version' );
delete_option( 'jlx_img_scan_data' );
delete_option( 'jlx_img_bulk_state' );

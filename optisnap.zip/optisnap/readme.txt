=== OptiSnap – Image Optimizer & Watermark ===
Contributors: optisnap
Tags: webp, image optimization, watermark, woocommerce, avif
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.13.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

تبدیل خودکار تصاویر به WebP، فشرده‌سازی، کراپ مربعی، سایزهای ریسپانسیو و واترمارک لوگو – سازگار با WooCommerce.

== Description ==

OptiSnap تصاویر کتابخانه رسانه را بهینه می‌کند:

* تبدیل خودکار JPEG/PNG به **WebP** (و AVIF اختیاری) با سه موتور: cwebp / Imagick / GD
* **Smart Mode**: انتخاب خودکار کیفیت بر اساس جزئیات تصویر و نقش آن در محصول
* کیفیت و ابعاد جدا برای تصویر اصلی محصول، گالری و سایر تصاویر
* کراپ مربعی ۱:۱ و سایزهای ریسپانسیو 480/768/1200 برای srcset
* **واترمارک دستی** لوگو با Backup خودکار، Preview و استثناهای دسته/محصول
* **Backup اجباری** همه فایل‌های اصلی + بازگردانی کامل
* پردازش گروهی با صف پایدار (Pause/Resume) و پردازش خودکار پس‌زمینه (WP-Cron)
* ابزار پاک‌سازی (تصاویر تکراری/بدون والد) و ساخت Alt خودکار
* REST API سازگار با اپ JLuxe Admin

== Installation ==

1. فایل زیپ را در «افزونه‌ها › افزودن › بارگذاری افزونه» آپلود و فعال کنید.
2. از منوی OptiSnap › تنظیمات، کیفیت‌ها و لوگوی واترمارک را تنظیم کنید.

== Frequently Asked Questions ==

= آیا فایل‌های اصلی حذف می‌شوند؟ =

خیر. طبق پیش‌فرض همه فایل‌های اصلی به `uploads/osn-backup/` منتقل می‌شوند و هر لحظه قابل بازگردانی هستند.

= روی nginx چه کنم؟ =

`.htaccess` فقط روی Apache کار می‌کند؛ در تنظیمات سرور nginx دسترسی به `/wp-content/uploads/osn-backup/` را مسدود کنید.

== Changelog ==

= 3.13.0 =
* Add an easy Alt text button for the product featured image and every gallery image, directly in the WooCommerce product editor.
* Edit existing alt text in a same-page dialog and save it to WordPress's standard attachment alt meta without opening Media Library.
* Secure AJAX save with nonce, capability checks, and sanitized input.
* Show optimization savings on product thumbnails, with before/after file size and dimensions in the profile details.

= 3.12.0 =
* Per-image OptiSnap profiles in the WooCommerce product editor.
* General high-quality, compact, desktop-banner, and mobile-banner profiles for Media Library images.
* Banner profiles preserve aspect ratio and disable square cropping by default.
* Profile changes never overwrite an already optimized file; restore first, then re-run optimization.


= 3.11.0 =
* Product Editor CSS/JS moved into versioned external assets.
* Product Editor status and notification strings now use the optisnap text domain.
* Audit report count corrected to 32 findings; remaining i18n/UI work documented for v4.0.


= 3.10.0 =
* قابلیت بزرگ: به‌روزرسانی خودکار لینک‌های قدیمی در محتوا — بعد از تبدیل photo.jpg به photo-jlx.webp، لینک‌های هاردکدشده در مطالب/محصولات/متاها به URL جدید منتقل می‌شوند (رفع مشکل شناخته‌شده 404 شدن لینک‌ها) + بازگردانی متقارن با Restore
* امنیت: دریافت Backup (Compare) با POST — دیگر nonce در URL/لاگ‌ها ثبت نمی‌شود
* امنیت: تصاویر «استثناءشده» از اندپوینت عمومی REST (/image/{id}) برنمی‌گردند + فیلتر osn_rest_image_payload
* بهبود: شفاف‌سازی برچسب شفافیت واترمارک (بیشتر = محوتر)
* بین‌المللی‌سازی: زیرساخت i18n (load_plugin_textdomain + languages/optisnap.pot)
* تست‌ها: ۴۰ تست (۹ تست جدید برای به‌روزرسانی URL محتوا)

= 3.9.2 =

= 3.9.2 =
* امنیت/پایداری: فعال‌سازی CI (بررسی خودکار syntax روی PHP 7.4 تا 8.3 + build)
* رفع باگ: پشتیبانی کامل EXIF Orientation (حالت‌های Flip: 2/4/5/7 — قبلاً فقط چرخش 3/6/8)
* رفع باگ: پاک‌سازی خودکار وضعیت «skipped» با تغییر تنظیمات پردازش (تصاویر دوباره ارزیابی می‌شوند)
* رفع باگ: نام‌گذاری خروجی Force Optimize (photo-1-jlx.webp دیگر به photo-1-jlx-jlx تبدیل نمی‌شود)
* کارایی: کوئری سبک‌تر شناسه محصولات در حالت products (SQL مستقیم به‌جای WP_Query)
* کیفیت: تست‌های خودکار (tests/run.php — ۳۱ تست با GD واقعی) + بررسی تطابق نسخه‌ها در build

= 3.9.1 =

= 3.9.1 =
* امنیت: رفع XSS در پنل ادمین، رفع Path Traversal در نمایش Backup، توقف نوشتن debug.log در وب‌روت، محافظت بهتر پوشه Backup (Apache 2.4/IIS/nginx هشدار)
* رفع باگ: احترام به Optimization Policy در REST، نشت فایل موقت Encode، نوشتن اتمیک (واترمارک/نور)، انباشت پسوند در Force، تشخیص آپلود تازه با post_date_gmt خالی، Race Condition صف پردازش، حذف جدول لاگ در Uninstall
* کارایی: کش درخواستی تشخیص نقش تصویر/محصول (حذف ده‌ها کوئری اضافه در فرانت)
* مخزن: افزودن کامل سورس، مستندات، CI و اسکریپت build

= 3.9.0 =
* مهاجرت برند به OptiSnap (osn) با مهاجرت یک‌باره داده‌ها

== Upgrade Notice ==

= 3.9.1 =
پیشنهاد اکید: به‌روزرسانی امنیتی و پایداری. بعد از به‌روزرسانی، یک‌بار صفحه «ابزارها › اسکن» را اجرا کنید.
